# Machine-Learning-Example-MATLAB
MATLAB code using the LIBSVM for pattern classification as shown in the tutorial https://www.youtube.com/watch?v=u6HIS7yLeMQ
